package com.example.demo.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.booking.Booking;
import com.example.demo.booking.Movie;
import com.example.demo.repository.BookingRepository;
import com.example.demo.repository.ShowRepository;
import com.example.demo.booking.Show;
import com.example.demo.booking.User;

@Service	
public class BookingService {
	@Autowired
	public BookingRepository bookingRepository;

	@Autowired
	public ShowRepository showRepository;


	public Optional<Booking> findByBookingId(Integer booking_id) { 
		// TODO Auto-generated method	  stub 
		return bookingRepository.findById(booking_id); 
	}



	public Iterable<Booking> getByStatus(String status) {
		// TODO Auto-generated method stub
		return bookingRepository.getByStatus(status);
	}

	public Booking cancelBooking(Integer booking_id) {
		// TODO Auto-generated method stub
		Optional<Booking> booking = bookingRepository.findById(booking_id);
		Booking booking1= booking.get();
		booking1.setStatus("Cancelled");
		return bookingRepository.save(booking1);
	}


	public Booking bookTickets(Booking booking) {		// TODO Auto-generated method stub
		//return null;
		Integer seatsBooked=booking.getSeatBooked();
		Integer showid=booking.getShowId().getShowId();
		Optional <Show> show=showRepository.findById(showid);
		int ticketPrice=show.get().getTicketCost();
		Integer seatsAvailable=show.get().getSeatAvailable();
		Integer remainingseats=seatsAvailable-seatsBooked;
		show.get().setSeatAvailable(remainingseats);
		System.out.println(remainingseats);
		System.out.println(ticketPrice);
		int amount=(seatsBooked*ticketPrice);
		booking.setTotalCost(amount);
		booking.setStatus("Booked");
		return bookingRepository.save(booking);
	}



	public Iterable<Booking> getAllBookings() {
		// TODO Auto-generated method stub
		return bookingRepository.findAll();
	}

	public Iterable<Show> getAllShows() {
		// TODO Auto-generated method stub
		return showRepository.findAll();
	}

	public Optional<Show> getByShowId(Integer showId) {
		// TODO Auto-generated method stub
		return showRepository.findById(showId);
	}

	public Show addNewShow(Show show) {
		// TODO Auto-generated method stub
		System.out.println("Hey");
		System.out.println(show.getMovieName().getMovieName());
		System.out.println(show.getTheatreName().getTheatreName());
		System.out.println(show.getShowDate());
		System.out.println(show.getSeatAvailable());
		System.out.println(show.getShowTimings());
		show.setShowStatus("Confirmed");
		System.out.println(show.getShowStatus());
		System.out.println(show.getTicketCost());
		return showRepository.save(show);
	}

	public Show updateShow(int showId, Show show) {
		// TODO Auto-generated method stub
		show.setShowId(showId);
		show.setMovieName(show.getMovieName());
		show.setTheatreName(show.getTheatreName());
		show.setSeatAvailable(show.getSeatAvailable());
		show.setShowDate(show.getShowDate());
		show.setShowStatus(show.getShowStatus());
		show.setShowTimings(show.getShowTimings());
		show.setTicketCost(show.getTicketCost());
		return showRepository.save(show);
	}

	public Show cancelShow(Integer showId) {
		// TODO Auto-generated method stub
		Optional<Show> show = showRepository.findById(showId);
		Show show1= show.get();
		show1.setShowStatus("Cancelled");
		return showRepository.save(show1);
	}

	public Iterable<Show> getByShowStatus(String status) {
		// TODO Auto-generated method stub
		return showRepository.getByShowStatus(status);
	}





}
