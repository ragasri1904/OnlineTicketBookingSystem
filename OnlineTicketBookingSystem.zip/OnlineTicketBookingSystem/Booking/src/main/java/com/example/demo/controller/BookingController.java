package com.example.demo.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.booking.Booking;
import com.example.demo.booking.Show;
import com.example.demo.service.BookingService;

@RestController
public class BookingController {

	@Autowired
	public BookingService bookingService;



	@RequestMapping(method = RequestMethod.GET, value="/listofbookings") 
	public Iterable<Booking> getAllBookings() { 
		return bookingService.getAllBookings();
	}


	@RequestMapping(method =RequestMethod.GET,value= "/booking/{booking_id}") 
	public Optional<Booking> findByBookingId(@PathVariable("booking_id") Integer booking_id) {
		return bookingService.findByBookingId(booking_id); 
	}
	
	


	@RequestMapping(method = RequestMethod.GET, value="/status/{status}") 
	public Iterable<Booking> getByStatus(@PathVariable("status")String status){ 
		return bookingService.getByStatus(status); 
	}

	@RequestMapping(value="/cancelbooking/{booking_id}") 
	public Booking cancelBooking(@PathVariable("booking_id") Integer booking_id) { 
		return	bookingService.cancelBooking(booking_id); 
	}
	

	@RequestMapping(method=RequestMethod.POST,value="/booktickets") 
	public Booking booktickets(@Valid @RequestBody Booking booking) { 
		return bookingService.bookTickets(booking); 
	}


	@RequestMapping(method = RequestMethod.GET,value="/allshows") 
	public Iterable<Show> getAllShows() { 
		return bookingService.getAllShows(); 
	}

	@RequestMapping(method= RequestMethod.GET,value="/show/{showId}") 
	public	Optional<Show> getByShowId(@PathVariable("showId")Integer showId) { 
		return bookingService.getByShowId(showId); }

	@RequestMapping(method=RequestMethod.POST,value="/newshow") 
	public Show	addNewShow(@Valid @RequestBody Show show) { 
		return bookingService.addNewShow(show); 
	}

	@RequestMapping(method = RequestMethod.PUT,value="/updateshow/{showId}")
	public Show updateShow(@PathVariable("showId")int showId, @Valid @RequestBody Show show) { 
		return bookingService.updateShow(showId,show); 
	}

	@RequestMapping(value="/cancelshow/{showId}") 
	public Show	cancelShow(@PathVariable("showId")Integer showId) { 
		return bookingService.cancelShow(showId); }

	@RequestMapping(method = RequestMethod.GET, value="/showstatus/{status}") 
	public Iterable<Show> getByShowStatus(@PathVariable("status")String status){ 
		return bookingService.getByShowStatus(status); 
	}
}
