package com.example.demo.booking;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="booking_table")
public class Booking {

	@Id
	@Column(name="booking_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookingId;

	private int seatBooked;
	private int totalCost;
	private String status;

	@OneToOne
	private User userName;

	@OneToOne
	private Show showId;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getSeatBooked() {
		return seatBooked;
	}

	public void setSeatBooked(int seatBooked) {
		this.seatBooked = seatBooked;
	}

	public int getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getUserName() {
		return userName;
	}

	public void setUserName(User userName) {
		this.userName = userName;
	}

	public Show getShowId() {
		return showId;
	}

	public void setShowId(Show showId) {
		this.showId = showId;
	}

	public Booking(int bookingId, int seatBooked, int totalCost, String status, User userName, Show showId) {
		super();
		this.bookingId = bookingId;
		this.seatBooked = seatBooked;
		this.totalCost = totalCost;
		this.status = status;
		this.userName = userName;
		this.showId = showId;
	}

	public Booking() {
		// TODO Auto-generated constructor stub
	}


}
