package com.example.demo.booking;


import java.sql.Date;
import java.sql.Time;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "show_table")
public class Show {

	@Id
	@Column(name="show_id")        	    
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private int showId;
	
	private int seatAvailable;
	private int ticketCost;
	private String showTimings;
	private Date showDate;
	private String showStatus;

	@OneToOne(cascade=CascadeType.MERGE)
	private Movie movieName;

	@OneToOne(cascade=CascadeType.MERGE)
	private Theatre theatreName;
	
	public int getShowId() {
		return showId;
	}
	public void setShowId(int showId) {
		this.showId = showId;
	}
	
	public Movie getMovieName() {
		return movieName;
	}
	public void setMovieName(Movie movieName) {
		this.movieName = movieName;
	}
	public Theatre getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(Theatre theatreName) {
		this.theatreName = theatreName;
	}
	public int getSeatAvailable() {
		return seatAvailable;
	}
	public void setSeatAvailable(int seatAvailable) {
		this.seatAvailable = seatAvailable;
	}
	public int getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(int ticketCost) {
		this.ticketCost = ticketCost;
	}
	public String getShowTimings() {
		return showTimings;
	}
	public void setShowTimings(String showTimings) {
		this.showTimings = showTimings;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public String getShowStatus() {
		return showStatus;
	}
	public void setShowStatus(String showStatus) {
		this.showStatus = showStatus;
	}
	public Show() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}

