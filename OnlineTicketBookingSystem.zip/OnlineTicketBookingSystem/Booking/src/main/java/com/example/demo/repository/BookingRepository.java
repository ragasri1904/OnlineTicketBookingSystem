package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.booking.Booking;
import com.example.demo.booking.User;

@Repository
public interface BookingRepository extends CrudRepository<Booking, Integer>{
	

	Iterable<Booking> getByStatus(String status);

}
