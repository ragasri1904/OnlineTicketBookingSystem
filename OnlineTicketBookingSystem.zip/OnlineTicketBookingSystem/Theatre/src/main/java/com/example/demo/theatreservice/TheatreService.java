package com.example.demo.theatreservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.repository.TheatreRepository;
import com.example.demo.theatre.Theatre;

@Service
public class TheatreService {
	
	@Autowired
	public TheatreRepository theatreRepository;

	public Iterable<Theatre> listoftheatres() {
		// TODO Auto-generated method stub
		Iterable<Theatre> theatre = theatreRepository.findAll();
		return theatre;
	}

	public Optional<Theatre> getTheatreName(String theatreName) {
		// TODO Auto-generated method stub
		
		return theatreRepository.findByTheatreName(theatreName);
	}

	public Theatre newTheatre(Theatre theatre) {
		// TODO Auto-generated method stub
		return theatreRepository.save(theatre);
	}

	public Theatre updateTheatre(int theatreId,Theatre theatre) {
		// TODO Auto-generated method stub		
		theatre.setTheatreId(theatreId);
		theatre.setSeatCapacity(theatre.getSeatCapacity());
		return theatreRepository.save(theatre);
	}

	public void deletetheatre(int theatreId) {
		// TODO Auto-generated method stub
		theatreRepository.deleteById(theatreId);
	}

}
