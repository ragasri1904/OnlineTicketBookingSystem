package com.example.demo.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.theatre.Theatre;
import com.example.demo.theatreservice.TheatreService;

@RestController
public class TheatreController {
	
	@Autowired
	public TheatreService theatreService;
	
	
	@RequestMapping("/listoftheatres")
	public Iterable<Theatre> lisoftheatre(){
		return theatreService.listoftheatres();
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/theatre/{theatreName}")
	public Optional<Theatre> getTheatreName(@PathVariable("theatreName")String theatreName){
		return theatreService.getTheatreName(theatreName);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addtheatre")
	public Theatre newtheatre(@Valid @RequestBody Theatre theatre) {
		return theatreService.newTheatre(theatre);
	}
	
	@RequestMapping(method= RequestMethod.PUT,value="/updatetheatre/{theatreId}")
	public Theatre updateTheatre(@PathVariable("theatreId") int theatreId,@Valid @RequestBody  Theatre theatre) {
		return theatreService.updateTheatre(theatreId,theatre);
	}
	
	@DeleteMapping("/deletetheatre/{theatreId}")
	public void deletetheatre(@PathVariable("theatreId")int theatreId) {
		theatreService.deletetheatre(theatreId);
	}
	
}
