package com.example.demo.theatre;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="theatre")
public class Theatre {
	@Id
	@Column(name="theatre_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private int theatreId;		
	private String theatreName;
	private int seatCapacity;
	
	
	public Theatre() {
		// TODO Auto-generated constructor stub
	}
	public Theatre(String theatreName, int seatCapacity,int theatreId) {
		super();
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.seatCapacity = seatCapacity;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	
	
}
