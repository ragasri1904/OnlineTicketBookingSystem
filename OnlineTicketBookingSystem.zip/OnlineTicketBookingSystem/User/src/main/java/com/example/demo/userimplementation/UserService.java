package com.example.demo.userimplementation;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.UserRepository;
import com.example.demo.user.User;

@Service
public class UserService {
	@Autowired
	public UserRepository userRepository;

	public Iterable<User> getAllUsers(){
		Iterable<User> userList = userRepository.findAll();		
		return userList;
	}

	public Optional<User> getUserbyId(String userName) {
		System.out.println("Hey i came here");
		System.out.println("userdetails");
		Optional<User> user = userRepository.findById(userName);

		System.out.println("user details :"+user.get());
		return user;
	}



	public User newUser(User user) { return userRepository.save(user); }


	public User updateuser(User user) {
		/*
		 * System.out.println("Hey i updated");
		 * 
		 * Optional<User> userUpdate = userRepository.findById(user.getUserName());
		 * System.out.println("hey username :"+user.getUserName());
		 * System.out.println("hey userUpdate"+userUpdate); User update =
		 * userUpdate.get(); System.out.println("hey update "+update);
		 * update.setPassword(user.getPassword());
		 * System.out.println("user.setPassword(update.getPassword());"+user.getPassword
		 * ()); update.setEmail(user.getEmail());
		 * System.out.println("user.setPassword(update.getEmail();"+user.getEmail());
		 * update.setPhoneNumber(user.getPhoneNumber());
		 * System.out.println("user.setPassword(update.getPhoneNumber();"+user.
		 * getPhoneNumber()); update.setRole(user.getRole());
		 * System.out.println("user.setPassword(update.getRole());"+user.getRole());
		 * System.out.println("user set role : "+user.getRole());
		 */
		return userRepository.save(user);

	}

	public void deleteUser(String userName) {		
		userRepository.deleteById(userName);
	}

	public String userLogin(User username) {
		User userName = null;
		Optional<User> users = userRepository.findById(username.getUserName());
		if(users.isPresent()){
			userName = users.get();
			if(userName.getPassword()==username.getPassword()) {
				return "Login Successfull"; //welcome
			}
			else {
				return "Invalid Password";
			}
		}
		else {
			return "Invalid Username";
		}
	}

}
