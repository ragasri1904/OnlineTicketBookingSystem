package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repository.UserRepository;
import com.example.demo.user.User;
import com.example.demo.userimplementation.UserService;

import org.springframework.http.HttpStatus;
@RestController
public class UserController {

	@Autowired
	public UserService userService;

	//	@RequestMapping("/")


	@RequestMapping("/listofusers")
	public Iterable<User> getAllUsers(){
		System.out.println("hey list of users");
		System.out.println("i ll give list :");
		return userService.getAllUsers();
	}


	@RequestMapping(method=RequestMethod.GET, value="/user/{username}")
	public Optional<User> getUserbyId(@PathVariable("username") String username) {
		System.out.println("hey user go to user service class");
		System.out.println("trying to get userName");
		System.out.println("username: "+username);
		return userService.getUserbyId(username);
		//		return "hello User";
	}

	@RequestMapping(method=RequestMethod.POST,value="/newusers")
	public User newUser(@Valid @RequestBody  User user) { 
		return userService.newUser(user);
	}
	 //Request method 'GET' not supported]


	@RequestMapping(method= RequestMethod.PUT,value="/updateuser/{username}")
	public User updateuser(@Valid @RequestBody User user) {
		System.out.println("Hey either i ll update or add you as a new user");
		return userService.updateuser(user);
	}

	@DeleteMapping("/deleteuser/{userName}")
	public void deleteUser(@PathVariable("userName") String userName) {
		System.out.println("Hey i ll delete you");
		userService.deleteUser(userName);
	}

	@RequestMapping("/login")
	public String userLogin(User username) {
		return userService.userLogin(username);
	}


}


