package com.example.demo.movieservice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.movie.Movie;
import com.example.demo.repository.MovieRepository;
@Service
public class MovieService {

	@Autowired
	public MovieRepository movieRepository;

	
	public Movie addNewMovie(Movie movie) { // TODO Auto-generated method stub
		return movieRepository.save(movie); 
	}


	public Movie updateMovie(int movieId,Movie movie) {	
		movie.setMovieId(movieId);
		movie.setLanguage(movie.getLanguage());
		movie.setRating(movie.getRating());
		return movieRepository.save(movie);
	}

	public void deleteMovie(int movieId) {
		// TODO Auto-generated method stub
		movieRepository.deleteById(movieId);
	}


	public Iterable<Movie> listofmovies() {
		// TODO Auto-generated method stub
		Iterable<Movie> movie = movieRepository.findAll(); 
		return movie;
	}
	

	
	  public Iterable<Movie> getMovieName(String movieName) { 
		  // TODO	  Auto-generated method stub
	  
	  return movieRepository.findByMovieName(movieName); }
	 
}
