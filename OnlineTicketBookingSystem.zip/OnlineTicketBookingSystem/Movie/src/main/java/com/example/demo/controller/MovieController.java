package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.movie.Movie;
import com.example.demo.movieservice.MovieService;

@RestController
//@RequestMapping("/movies")
public class MovieController {
	@Autowired
	public MovieService movieService;
	
	@RequestMapping("/listofmovies")
	public Iterable<Movie> lisofmovies(){
		return movieService.listofmovies();
	}

	
	  @RequestMapping(method=RequestMethod.GET,value="/movie/{movieName}")
	  public	  Iterable<Movie> getMovieName(@PathVariable("movieName")String movieName){
	  return movieService.getMovieName(movieName); }
	 
	 
	@RequestMapping(method=RequestMethod.POST,value="/newmovie") 
	public Movie addNewMovie(@Valid @RequestBody Movie movie) {
		System.out.println("hey i ll create you");
		return movieService.addNewMovie(movie); 
	}

	
	@RequestMapping(method= RequestMethod.PUT,value="/updatemovie/{movieId}")
	public Movie updateMovie(@PathVariable("movieId")int movieId, @Valid @RequestBody Movie movie) {
		System.out.println("Hey either i ll update or add you as a new user");
		return movieService.updateMovie(movieId,movie);
	}
	@DeleteMapping("/delete/{movieId}")
	public void deleteMovie(@PathVariable("movieId")int movieId) {
		System.out.println("i ll delete movie name");
		movieService.deleteMovie(movieId);
	}
}
